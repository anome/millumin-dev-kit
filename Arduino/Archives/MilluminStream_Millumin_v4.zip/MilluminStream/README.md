Millumin Stream
============

MilluminStream is an small, efficient, library that allows Arduinos to send and receive serial data packets with Millumin


## Dependencies 

MilluminStream is based on packetSerial. 
This library can be found here : https://github.com/bakercp/PacketSerial .
You will need it to use MilluminStream.

## License
Creative Commons Attribution-NonCommercial 4.0 International Public License
