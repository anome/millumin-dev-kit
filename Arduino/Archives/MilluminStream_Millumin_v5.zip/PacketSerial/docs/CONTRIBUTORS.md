# Contributors

- Christopher Baker [@bakercp](https://github.com/bakercp) - Primary author.
- Antoine Villeret [@avilleret](https://github.com/avilleret) - SLIP Encoding.
- Anton Viktorov [@latonita](https://github.com/latonita) - Bugfixes.
- [@per1234](https://github.com/per1234) - Metadata.
- George Profenza [@orgicus](https://github.com/orgicus) - API Suggestions.

_For and up-to-date list of contributors, see [contributors](../graphs/contributors)._
